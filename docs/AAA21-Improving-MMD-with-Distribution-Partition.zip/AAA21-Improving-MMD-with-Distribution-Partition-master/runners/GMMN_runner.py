import os
import random
import numpy as np
import tqdm
from itertools import chain
import logging

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as transforms
from torchvision.utils import save_image, make_grid
import tensorboardX
from PIL import Image

from datasets import data
from models import generator
#from models.utils import AverageMeterSet
from losses import mmd

import time

__all__ = ['GMMNRunner']

NO_LABEL = -1

class GMMNRunner():
    def __init__(self, args, config):
        self.args = args
        self.config = config
        if self.config.data.dataset in ['CIFAR10', 'MNIST', 'SVHN']:
            self.config.num_targets = 10
        else:
            self.config.num_targets = 0

    def get_optimizer(self, parameters):
        if self.config.optim.optimizer == 'Adam':
            return optim.Adam(
                parameters,
                lr=self.config.optim.lr,
                weight_decay=self.config.optim.weight_decay,
                betas=(self.config.optim.beta1, 0.999),
                amsgrad=self.config.optim.amsgrad
            )
        elif self.config.optim.optimizer == 'RMSProp':
            return optim.RMSprop(
                parameters,
                lr=self.config.optim.lr,
                weight_decay=self.config.optim.weight_decay
            )
        elif self.config.optim.optimizer == 'SGD':
            return optim.SGD(parameters, lr=self.config.optim.lr, momentum=0.9)
        else:
            raise NotImplementedError('Optimizer {} not understood.'
                                      .format(self.config.optim.optimizer))

    def create_model(self):
        logging.info("=> creating generator model '{arch}'".format(
            arch=self.config.generator.arch))

        if self.config.data.dataset == 'MNIST':
            model = generator.create_mnist_generator(self.config).to(self.config.device)
        elif self.config.data.dataset == 'CIFAR10':
            model = generator.create_cifar10_generator(self.config).to(self.config.device)
        elif self.config.data.dataset == 'CELEBA':
            model = generator.create_celeba_generator(self.config).to(self.config.device)

        model = torch.nn.DataParallel(model)
        return model

    def save_images(self,x,y,grid_size, channel, image_size, name):
        sample = x
        sample = sample.view(
            grid_size ** 2,
            channel,
            image_size,
            image_size
        )
        image_grid = make_grid(sample, nrow=grid_size)

        if not os.path.exists(self.args.image_folder):
            os.makedirs(self.args.image_folder)

        save_image(image_grid, os.path.join(
            self.args.image_folder, name))

    def train(self):

        if self.config.data.random_flip is False:
            tran_transform = transforms.Compose([
                transforms.Resize(self.config.data.image_size),
                transforms.ToTensor()
            ])
        else:
            tran_transform = transforms.Compose([
                transforms.Resize(self.config.data.image_size),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.ToTensor()
            ])

        test_transform = transforms.Compose([
            transforms.Resize(self.config.data.image_size),
            transforms.ToTensor()
        ])

        input_dim = self.config.data.image_size ** 2 * self.config.data.channels
        self.config.input_dim = input_dim

        print('load data .... ')
        data_loader, test_loader = data.create_data_loaders_batch(
            tran_transform, test_transform, config=self.config, args=self.args)

        if False:
            print('start test .... ')
            for i, (X, y) in enumerate(data_loader):
                if (i == 0):
                    self.save_images(X,y, 8 ,3, 64,'{}_sample_{}.png'.format(self.config.data.dataset,i))
            print('test down .... ')
            return 

        generator = self.create_model()
        optimizer = self.get_optimizer(generator.parameters())

        if self.args.resume_training:
            states = torch.load(os.path.join(self.args.log, 'checkpoint.pth'))
            generator.load_state_dict(states[0])
            optimizer.load_state_dict(states[1])

        step = 0
        #meters = AverageMeterSet()

        bs = self.config.training.batch_size
        bsm = self.config.training.batch_size_multiplier
        XX = 0

        YY = torch.rand(60000, self.config.model.nz_x, 1, 1)
        self.YY = YY.to(self.config.device)

        print(self.YY.size())

        self.batch = self.config.data.batch

        d = []
        for i, (X,y) in enumerate(data_loader):
            if i > self.batch:
                break
            d = d + [(X,y)]

        t = time.time()

        for epoch in range(self.config.training.n_epochs):
            generator.train()

            #for i, (X, y) in enumerate(data_loader):
            for i, (X, y) in enumerate(d):
                step += 1
            
                y = self.YY[i*bs:(i+1)*bs]

                X = X.to(self.config.device)
                y = y.to(self.config.device)
                total_loss = 0

                if not X.size()[0] == bs:
                    continue

                ###### generate samples
                ## z = torch.rand(bs * bsm, self.config.model.nz, 1, 1).to(self.config.device)
                ## z = torch.cat((z,y), dim=1)
                #z = self.z
                #print(z.size())
                #print(generator)

                z = torch.rand(bs * bsm, self.config.model.nz, 1, 1).to(self.config.device)
                samples = generator(z)
                #print('sample size: ', samples.size())
                #print('X size: ', X.size())
                #return 

                samples = samples.view(bs * bsm, -1)
                X = X.view(bs, -1)
                y = y.view(bs * bsm, -1)

                loss_mmd = mmd.mmd(samples, X, self.config, biased=True)
                #loss_mmd = mmd.cmmd(y,samples,y[:bs],X, self.config, 
                #        lambda_=self.config.model.lambda_,biased=True)

                total_loss = loss_mmd * 100

                optimizer.zero_grad()
                total_loss.backward()
                optimizer.step()

                if step % 10 == 0:
                    logging.info("step: {} total_loss: {:.3f} time: {:.3f}"
                               .format(step, total_loss.item() * 100, time.time() - t))
                    t = time.time()

                #if step >= self.config.training.n_iters:
                #    return 0

                if step % self.config.training.snapshot_freq == 0:
                    states = [
                        generator.state_dict(),
                        optimizer.state_dict(),
                    ]
                    torch.save(states, os.path.join(
                        self.args.log, 'checkpoint_{}.pth'.format(step)))
                    torch.save(states, os.path.join(
                        self.args.log, 'checkpoint.pth'))

                if step % self.config.training.eval_freq == 0:
                    self.eval(generator,step)

    def eval(self, generator, step, grid_size = 8):

        generator.eval()
        g2 = grid_size * grid_size
        bs = self.config.training.batch_size
        bsm = self.config.training.batch_size_multiplier

        n = g2 // (bs * bsm)

        if not g2 % (bs * bsm) == 0:
            n += 1

        offset = 0

        ##KK = self.YY[:2000].clone()
        KK = torch.rand(bs * bsm, self.config.model.nz, 1, 1).to(self.config.device)

        if True:
            tt1 = KK[:1].clone()
            tt = KK[1:2].clone()
            ttd = (tt - tt1).clone()
            for i in range(48):
                tt = tt1 + ttd*i/48.
                ##tt[0][6][0][0] =  -3 + 0.03 * i
                #vv = (torch.rand(1, 16, 1, 1).to(self.config.device) - 0.5) * 2.5
                #tt = vv + tt
                tt = tt.to(self.config.device)
                #print(tt[0][0][0][0])
                KK = torch.cat((tt,KK), dim=0)

        KK = KK.to(self.config.device)

        z = torch.rand(bs * bsm, self.config.model.nz, 1, 1).to(self.config.device)
        #z = torch.cat((z,KK[offset:offset+bs]), dim=1)
        samples = generator(z)
        X = samples

        
        for i in range(1,n):
            z = torch.rand(bs * bsm, self.config.model.nz, 1, 1).to(self.config.device)
            idx = i % self.batch
            if idx == 10:
                idx = 0
            #z = torch.cat((z,KK[offset+idx*bs:offset+(idx+1)*bs]), dim=1)
            #z = self.z
            samples = generator(z)
            X = torch.cat((X, samples), 0)

        print('n: ', n)
        print('bs * bsm: ', bs*bsm)
        print('g2: ', g2)
        print(X.size())
        X = X[:g2]
        print(X.size())

        self.save_images(X, None, grid_size, self.config.data.channels, 
                self.config.data.image_size, 
                '{}_GMMN_{}_batch_bsm_{}_lambda_{}_ngf_{}_step_{}.png'.format(self.config.data.dataset, self.batch,
                bsm, self.config.model.lambda_, self.config.model.ngf, step))


    def test(self, grid_size = 8*1):
        states = torch.load(os.path.join(self.args.log, 'checkpoint.pth'),
                            map_location=self.config.device)
        generator = self.create_model()
        generator.load_state_dict(states[0])

        YY = torch.rand(60000, self.config.model.nz_x, 1, 1)
        self.YY = YY

        if False:
            for i in range(24 * 6):
                tt = YY[4:5].clone()
                vv = (torch.rand(1, 64, 1, 1).to(self.config.device) - 0.5) * 1
                tt = vv + tt
                tt = tt.to(self.config.device)
                #print(tt[0][0][0][0])
                self.YY = torch.cat((tt,self.YY), dim=0)

        if True:
            tt1 = YY[1:2].clone()
            tt = YY[0:1].clone()
            ttd = (tt - tt1).clone()
            for i in range(16):
                tt = tt1 + ttd*i/16.
                tt = tt.to(self.config.device)
                #print(tt[0][0][0][0])
                self.YY = torch.cat((tt,self.YY), dim=0)

        if False:
            for i in range(240):
                tt = YY[77:78].clone()
                tt[0][0][0][0] =  -3 + 0.026 * i
                tt = tt.to(self.config.device)
                #print(tt[0][0][0][0])
                self.YY = torch.cat((tt,self.YY), dim=0)

        if False:
            for i in range(24*12):
                r = random.randint(0,40000)
                tt = YY[r:r+1].clone()
                self.YY = torch.cat((tt,self.YY), dim=0)
                #tt[0][0][0][0] =  -3 + 0.026 * i
                #vv = (torch.rand(1, 64, 1, 1).to(self.config.device) - 0.5) * 1
                vv = (torch.randn(1, 64, 1, 1).to(self.config.device)) * 0.5
                tt = vv + tt
                tt = tt.to(self.config.device)
                #print(tt[0][0][0][0])
                self.YY = torch.cat((tt,self.YY), dim=0)

        if False:
            #for i in range(24*12):
            for i in range(24*24):
                r = random.randint(0,40000)
                tt = YY[r:r+1].clone()
                ##self.YY = torch.cat((tt,self.YY), dim=0)
                for j in range(10):
                    dd = random.randint(0,self.config.model.nz_x-1)
                    kk = (random.randint(0,500) - 250)/ 250. * 0.3
                    tt[0][dd][0][0] = tt[0][dd][0][0] + kk
                tt = tt.to(self.config.device)
                self.YY = torch.cat((tt,self.YY), dim=0)

        if not os.path.exists(self.args.image_folder):
            os.makedirs(self.args.image_folder)
        generator.eval()

        g2 = grid_size * grid_size
        bs = self.config.training.batch_size
        bsm = self.config.training.batch_size_multiplier
        self.batch = self.config.data.batch

        n = g2 // (bs * bsm)

        if not g2 % (bs * bsm) == 0:
            n += 1

        offset = 0
        #offset = 2000

        z = torch.rand(bs * bsm, self.config.model.nz, 1, 1).to(self.config.device)
        #z = torch.cat((z,self.YY[60000:60000+bs]), dim=1)
        #z = torch.cat((z,self.YY[offset:offset+bs]), dim=1)
        samples = generator(z)
        X = samples

        for i in range(1,n):
            z = torch.rand(bs * bsm, self.config.model.nz, 1, 1).to(self.config.device)
            idx = i % self.batch
            if idx == 100:
                idx = 0
            #z = torch.cat((z,self.YY[60000+idx*bs:60000+(idx+1)*bs]), dim=1)
            #z = torch.cat((z,self.YY[offset+idx*bs:offset+(idx+1)*bs]), dim=1)
            #z = self.z
            samples = generator(z)
            X = torch.cat((X, samples), 0)

        print('n: ', n)
        print('bs * bsm: ', bs*bsm)
        print('g2: ', g2)
        print(X.size())
        X = X[:g2]
        print('sample size:', X.size())

        ### save as numpy
        nparr = X.cpu().detach().numpy()
        np.save('/home/yongren/cifer_gen_numpy', nparr)
        torch.save(X, '/home/yongren/cifer_gen_tensor.pt')

        self.save_images(X, None, grid_size, self.config.data.channels, 
                self.config.data.image_size, 
                'test_{}_GMMN_{}_batch_bsm_{}_lambda_{}_ngf_{}_step_10k_7.png'.format(self.config.data.dataset, 
                    self.batch, bsm, self.config.model.lambda_, self.config.model.ngf))
