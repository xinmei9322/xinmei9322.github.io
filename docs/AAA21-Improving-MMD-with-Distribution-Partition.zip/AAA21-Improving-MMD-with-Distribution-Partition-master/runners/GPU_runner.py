import os
import numpy as np
import tqdm
from itertools import chain
import logging

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as transforms
from torchvision.utils import save_image, make_grid
import tensorboardX
from PIL import Image

from datasets import data
from models import generator
#from models.utils import AverageMeterSet
from losses import mmd


__all__ = ['GPURunner']

NO_LABEL = -1

class GPURunner():
    def __init__(self, args, config):
        self.args = args
        self.config = config
        if self.config.data.dataset in ['CIFAR10', 'MNIST', 'SVHN']:
            self.config.num_targets = 10
        else:
            self.config.num_targets = 0

    def get_optimizer(self, parameters):
        if self.config.optim.optimizer == 'Adam':
            return optim.Adam(
                parameters,
                lr=self.config.optim.lr,
                weight_decay=self.config.optim.weight_decay,
                betas=(self.config.optim.beta1, 0.999),
                amsgrad=self.config.optim.amsgrad
            )
        elif self.config.optim.optimizer == 'RMSProp':
            return optim.RMSprop(
                parameters,
                lr=self.config.optim.lr,
                weight_decay=self.config.optim.weight_decay
            )
        elif self.config.optim.optimizer == 'SGD':
            return optim.SGD(parameters, lr=self.config.optim.lr, momentum=0.9)
        else:
            raise NotImplementedError('Optimizer {} not understood.'
                                      .format(self.config.optim.optimizer))

    def create_model(self):
        logging.info("=> creating generator model '{arch}'".format(
            arch=self.config.generator.arch))
        model = generator.create_mnist_generator(self.config).to(self.config.device)
        model = torch.nn.DataParallel(model)
        return model

    def save_images(self,x,y,grid_size, channel, image_size, name):
        sample = x
        sample = sample.view(
            grid_size ** 2,
            channel,
            image_size,
            image_size
        )
        image_grid = make_grid(sample, nrow=grid_size)

        if not os.path.exists(self.args.image_folder):
            os.makedirs(self.args.image_folder)

        save_image(image_grid, os.path.join(
            self.args.image_folder, name))

    def train(self):

        if self.config.data.random_flip is False:
            tran_transform = transforms.Compose([
                transforms.Resize(self.config.data.image_size),
                transforms.ToTensor()
            ])
        else:
            tran_transform = transforms.Compose([
                transforms.Resize(self.config.data.image_size),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.ToTensor()
            ])

        test_transform = transforms.Compose([
            transforms.Resize(self.config.data.image_size),
            transforms.ToTensor()
        ])

        input_dim = self.config.data.image_size ** 2 * self.config.data.channels
        self.config.input_dim = input_dim

        print('load data .... ')
        data_loader, test_loader = data.create_data_loaders_batch(
            tran_transform, test_transform, config=self.config, args=self.args)

        if False:
            print('start test .... ')
            for i, (X, y) in enumerate(data_loader):
                if (i == 0):
                    self.save_images(X,y,8 ,3,32,'cifar10_sample_{}.png'.format(i))
            print('test down .... ')

        generator = self.create_model()
        optimizer = self.get_optimizer(generator.parameters())

        if self.args.resume_training:
            states = torch.load(os.path.join(self.args.log, 'checkpoint.pth'))
            generator.load_state_dict(states[0])
            optimizer.load_state_dict(states[1])

        step = 0
        #meters = AverageMeterSet()

        bs = self.config.training.batch_size
        bsm = self.config.training.batch_size_multiplier
        XX = 0
        YY = torch.rand(60000, self.config.model.nz_x, 1, 1)
        self.YY = YY
        print(self.YY.size())
        self.batch = self.config.data.batch

        d = []
        for i, (X,y) in enumerate(data_loader):
            if i > self.batch:
                break
            d = d + [(X,y)]

        for epoch in range(self.config.training.n_epochs):
            generator.train()

            #for i, (X, y) in enumerate(data_loader):
            for i, (X, y) in enumerate(d):
                step += 1
            
                y = self.YY[i*bs:(i+1)*bs]

                X = X.to(self.config.device)
                y = y.to(self.config.device)
                total_loss = 0

                if not X.size()[0] == bs:
                    continue

                ###### generate samples
                z = torch.rand(bs * bsm, self.config.model.nz, 1, 1).to(self.config.device)
                z = torch.cat((z,y), dim=1)
                #z = self.z
                #print(z.size())
                #print(generator)
                samples = generator(z)
                #print('sample size: ', samples.size())
                #print('X size: ', X.size())

                samples = samples.view(bs * bsm, -1)
                X = X.view(bs, -1)
                y = y.view(bs * bsm, -1)

                #loss_mmd = mmd.mmd(samples, X, self.config, biased=True)
                loss_mmd = mmd.cmmd(y,samples,y[:bs],X, self.config, 
                        lambda_=self.config.model.lambda_,biased=True)

                total_loss = loss_mmd * 100

                optimizer.zero_grad()
                total_loss.backward()
                optimizer.step()

                if step % 10 == 0:
                    logging.info("step: {} total_loss: {:.3f}"
                               .format(step, total_loss.item() * 100))

                #if step >= self.config.training.n_iters:
                #    return 0
                if False:

                    if step % self.config.training.snapshot_freq == 0:
                        states = [
                            generator.state_dict(),
                            optimizer.state_dict(),
                        ]
                        torch.save(states, os.path.join(
                            self.args.log, 'checkpoint_{}.pth'.format(step)))
                        torch.save(states, os.path.join(
                            self.args.log, 'checkpoint.pth'))

                    if step % 2000 == 0:
                        self.eval(generator,step)

    def eval(self, generator, step, grid_size = 8*3):

        generator.eval()
        g2 = grid_size * grid_size
        bs = self.config.training.batch_size
        bsm = self.config.training.batch_size_multiplier

        n = g2 // (bs * bsm)

        if not g2 % (bs * bsm) == 0:
            n += 1

        z = torch.rand(bs * bsm, self.config.model.nz, 1, 1)
        z = torch.cat((z,self.YY[:bs]), dim=1)
        samples = generator(z)
        X = samples

        for i in range(n-1):
            z = torch.rand(bs * bsm, self.config.model.nz, 1, 1)
            idx = i % self.batch
            if idx == 4:
                idx = 0
            z = torch.cat((z,self.YY[idx*bs:(idx+1)*bs]), dim=1)
            #z = self.z
            samples = generator(z)
            X = torch.cat((X, samples), 0)

        print('n: ', n)
        print('bs * bsm: ', bs*bsm)
        print('g2: ', g2)
        print(X.size())
        X = X[:g2]
        print(X.size())

        self.save_images(X, None, grid_size, self.config.data.channels, 
                self.config.data.image_size, 
                'mnist_cmmd_{}_batch_bsm_{}_lambda_{}_ngf_{}_step_{}.png'.format(self.batch,
                bsm, self.config.model.lambda_, self.config.model.ngf, step))


    def test(self, grid_size = 8*3):
        states = torch.load(os.path.join(self.args.log, 'checkpoint.pth'),
                            map_location=self.config.device)
        generator = self.create_model()
        generator.load_state_dict(states[0])
        YY = torch.rand(160000, self.config.model.nz_x, 1, 1)
        self.YY = YY

        if not os.path.exists(self.args.image_folder):
            os.makedirs(self.args.image_folder)
        generator.eval()

        g2 = grid_size * grid_size
        bs = self.config.training.batch_size
        bsm = self.config.training.batch_size_multiplier
        self.batch = self.config.data.batch

        n = g2 // (bs * bsm)

        if not g2 % (bs * bsm) == 0:
            n += 1

        z = torch.rand(bs * bsm, self.config.model.nz, 1, 1)
        z = torch.cat((z,self.YY[60000:60000+bs]), dim=1)
        samples = generator(z)
        X = samples

        for i in range(n-1):
            z = torch.rand(bs * bsm, self.config.model.nz, 1, 1)
            idx = i % self.batch
            if idx == 4:
                idx = 0
            z = torch.cat((z,self.YY[60000+idx*bs:60000+(idx+1)*bs]), dim=1)
            #z = self.z
            samples = generator(z)
            X = torch.cat((X, samples), 0)

        print('n: ', n)
        print('bs * bsm: ', bs*bsm)
        print('g2: ', g2)
        print(X.size())
        X = X[:g2]
        print(X.size())

        self.save_images(X, None, grid_size, self.config.data.channels, 
                self.config.data.image_size, 
                'test_mnist_cmmd_{}_batch_bsm_{}_lambda_{}_ngf_{}.png'.format(self.batch,
                bsm, self.config.model.lambda_, self.config.model.ngf))

