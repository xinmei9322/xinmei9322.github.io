import os
import numpy as np
import tqdm
from itertools import chain
import logging

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as transforms
from torchvision.utils import save_image, make_grid
import tensorboardX
from PIL import Image

from datasets import data
from models import generator
#from models.utils import AverageMeterSet
from losses import mmd


__all__ = ['GMMNDPRunner']

NO_LABEL = -1

class GMMNDPRunner():
    def __init__(self, args, config):
        self.args = args
        self.config = config
        if self.config.data.dataset in ['CIFAR10', 'MNIST', 'SVHN']:
            self.config.num_targets = 10
        else:
            self.config.num_targets = 0

    def get_optimizer(self, parameters):
        if self.config.optim.optimizer == 'Adam':
            return optim.Adam(
                parameters,
                lr=self.config.optim.lr,
                weight_decay=self.config.optim.weight_decay,
                betas=(self.config.optim.beta1, 0.999),
                amsgrad=self.config.optim.amsgrad
            )
        elif self.config.optim.optimizer == 'RMSProp':
            return optim.RMSprop(
                parameters,
                lr=self.config.optim.lr,
                weight_decay=self.config.optim.weight_decay
            )
        elif self.config.optim.optimizer == 'SGD':
            return optim.SGD(parameters, lr=self.config.optim.lr, momentum=0.9)
        else:
            raise NotImplementedError('Optimizer {} not understood.'
                                      .format(self.config.optim.optimizer))

    def create_model(self):
        #logging.info("=> creating generator model '{arch}'".format(
        #    arch=self.config.generator.arch))
        #model_factory = generator_arch.__dict__[self.config.generator.arch]
        #model_params = dict(pretrained=False,
        #                    num_classes=self.config.num_targets)
        #model = model_factory(**model_params).to(self.config.device)
        #model = torch.nn.DataParallel(model)
        #return model
        model = generator.create_mnist_generator(self.config).to(self.config.device)
        model = torch.nn.DataParallel(model)
        return model

    def save_images(self,x,y,grid_size, channel, image_size, name):
        sample = x
        sample = sample.view(
            grid_size ** 2,
            channel,
            image_size,
            image_size
        )
        image_grid = make_grid(sample, nrow=grid_size)
        save_image(image_grid, os.path.join(
            self.args.image_folder, name))

    def train(self):
        #bs = self.config.traning.batch_size
        #self.z = torch.rand(bs, self.config.model.nz, 1, 1)

        if self.config.data.random_flip is False:
            tran_transform = transforms.Compose([
                transforms.Resize(self.config.data.image_size),
                transforms.ToTensor()
            ])
        else:
            tran_transform = transforms.Compose([
                transforms.Resize(self.config.data.image_size),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.ToTensor()
            ])

        test_transform = transforms.Compose([
            transforms.Resize(self.config.data.image_size),
            transforms.ToTensor()
        ])

        input_dim = self.config.data.image_size ** 2 * self.config.data.channels
        self.config.input_dim = input_dim

        print('load data .... ')
        data_loader, test_loader = data.create_data_loaders_batch(
            tran_transform, test_transform, config=self.config, args=self.args)

        if False:
            print('start test .... ')
            for i, (X, y) in enumerate(data_loader):
                if (i == 0):
                    self.save_images(X,y,8 ,3,32,'cifar10_sample_{}.png'.format(i))
            print('test down .... ')

        generator = self.create_model()
        optimizer = self.get_optimizer(generator.parameters())

        if self.args.resume_training:
            states = torch.load(os.path.join(self.args.log, 'checkpoint.pth'))
            generator.load_state_dict(states[0])
            optimizer.load_state_dict(states[1])

        step = 0
        #meters = AverageMeterSet()

        for epoch in range(self.config.training.n_epochs):
            generator.train()

            XX = 0
            YY = 0
            for i, (X, y) in enumerate(data_loader):
                step += 1
                if i == 0:
                    XX = X
                    YY = y
                else:
                    break

            for i in range(10000000):
                step = i
                X = XX
                y = YY

                X = X.to(self.config.device)
                y = y.to(self.config.device)
                total_loss = 0

                bs = self.config.training.batch_size
                bsm = self.config.training.batch_size_multiplier

                if not X.size()[0] == bs:
                    continue

                ###### generate samples
                z = torch.rand(bs * bsm, self.config.model.nz, 1, 1)
                #z = self.z
                #print(z.size())
                #print(generator)
                samples = generator(z)
                #print('sample size: ', samples.size())
                #print('X size: ', X.size())

                samples = samples.view(bs * bsm, -1)
                X = X.view(bs, -1)

                loss_mmd = mmd.mmd(samples, X, self.config, biased=True)

                total_loss = loss_mmd * 100

                optimizer.zero_grad()
                total_loss.backward()
                optimizer.step()

                if i % 10 == 0:
                    logging.info("step: {} total_loss: {:.3f}"
                               .format(step, total_loss.item() * 100))

                #if step >= self.config.training.n_iters:
                #    return 0

                if step % self.config.training.snapshot_freq == 0:
                    states = [
                        generator.state_dict(),
                        optimizer.state_dict(),
                    ]
                    torch.save(states, os.path.join(
                        self.args.log, 'checkpoint_{}.pth'.format(step)))
                    torch.save(states, os.path.join(
                        self.args.log, 'checkpoint.pth'))

                if step % 2000 == 0:
                    self.eval(generator,step)

    def eval(self, generator, step, grid_size = 8*3):

        generator.eval()
        g2 = grid_size * grid_size
        bs = self.config.training.batch_size
        bsm = self.config.training.batch_size_multiplier

        n = g2 // (bs * bsm)

        if not g2 % bs == 0:
            n += 1

        z = torch.rand(bs * bsm, self.config.model.nz, 1, 1)
        samples = generator(z)
        X = samples

        for i in range(n-1):
            z = torch.rand(bs * bsm, self.config.model.nz, 1, 1)
            #z = self.z
            samples = generator(z)
            X = torch.cat((X, samples), 0)

        X = X[:g2]

        print(X.size())
        self.save_images(X, None, grid_size, self.config.data.channels, 
                self.config.data.image_size, 'mnist_mmd_1_batch_step_{}.png'.format(step))


    def test(self):
        states = torch.load(os.path.join(self.args.log, 'checkpoint.pth'),
                            map_location=self.config.device)
        generator = self.create_model()
        generator.load_state_dict(states[0])

        if not os.path.exists(self.args.image_folder):
            os.makedirs(self.args.image_folder)
        generator.eval()
