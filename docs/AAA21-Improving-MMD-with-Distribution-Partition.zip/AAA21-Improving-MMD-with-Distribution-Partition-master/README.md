# Boosting-MMD-with-Distribution-Partition
Project for paper.
