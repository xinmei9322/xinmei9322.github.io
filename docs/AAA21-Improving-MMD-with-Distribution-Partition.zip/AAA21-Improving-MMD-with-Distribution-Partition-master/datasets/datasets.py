import torchvision.transforms as transforms
import sys
from . import data
import os

def export(fn):
    mod = sys.modules[fn.__module__]
    if hasattr(mod, '__all__'):
        mod.__all__.append(fn.__name__)
    else:
        mod.__all__ = [fn.__name__]
    return fn


@export
def imagenet():
    channel_stats = dict(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
    tran_transform = data.TransformTwice(transforms.Compose([
        transforms.RandomRotation(10),
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
        transforms.ToTensor(),
        transforms.Normalize(**channel_stats)
    ]))
    test_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(**channel_stats)
    ])

    return {
        'tran_transform': tran_transform,
        'test_transform': test_transform,
        'datadir': 'data-local/images/ilsvrc2012/',
        'num_classes': 1000
    }


@export
def cifar10():
    channel_stats = dict(mean=[0.4914, 0.4822, 0.4465],
                         std=[0.2470,  0.2435,  0.2616])
    tran_transform = \
        transforms.Compose([
        data.RandomTranslateWithReflect(4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        # transforms.Normalize(**channel_stats)
    ])  # ##data.TransformTwice  transforms.Resize(self.config.data.image_size),

    test_transform = transforms.Compose([
        transforms.ToTensor(),
        # transforms.Normalize(**channel_stats)
    ])

    return {
        'tran_transform': tran_transform,
        'test_transform': test_transform,
    }



@export
def cifar100():
    channel_stats = dict(mean=[0.4914, 0.4822, 0.4465],
                         std=[0.2470,  0.2435,  0.2616]) # should we use different stats - do this
    tran_transform = data.TransformTwice(transforms.Compose([
        data.RandomTranslateWithReflect(4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(**channel_stats)
    ]))
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(**channel_stats)
    ])

    if os.path.isdir("/scratch/datasets/cifar/cifar100/by-image/"):
        datadir = "/scratch/datasets/cifar/cifar100/by-image/"
    elif os.path.isdir("data-local/images/cifar/cifar100/by-image"):
        datadir = "data-local/images/cifar/cifar100/by-image"
    print("Using CIFAR-100 from", datadir)

    return {
        'tran_transform': tran_transform,
        'test_transform': test_transform,
        'datadir': datadir,
        'num_classes': 100
    }






















