"""Functions to load data from folders and augment it"""

import itertools
import os.path
import torch
from PIL import Image
import numpy as np
from torch.utils.data.sampler import Sampler
from torch.utils.data.sampler import BatchSampler, SubsetRandomSampler
import torchvision
from torchvision.datasets import MNIST, CIFAR10, SVHN
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
import datasets
from datasets.celeba import CelebA
NO_LABEL = -1


class RandomTranslateWithReflect:
    """Translate image randomly

    Translate vertically and horizontally by n pixels where
    n is integer drawn uniformly independently for each axis
    from [-max_translation, max_translation].

    Fill the uncovered blank area with reflect padding.
    """

    def __init__(self, max_translation):
        self.max_translation = max_translation

    def __call__(self, old_image):
        xtranslation, ytranslation = np.random.randint(-self.max_translation,
                                                       self.max_translation + 1,
                                                       size=2)
        xpad, ypad = abs(xtranslation), abs(ytranslation)
        xsize, ysize = old_image.size

        flipped_lr = old_image.transpose(Image.FLIP_LEFT_RIGHT)
        flipped_tb = old_image.transpose(Image.FLIP_TOP_BOTTOM)
        flipped_both = old_image.transpose(Image.ROTATE_180)

        new_image = Image.new("RGB", (xsize + 2 * xpad, ysize + 2 * ypad))

        new_image.paste(old_image, (xpad, ypad))

        new_image.paste(flipped_lr, (xpad + xsize - 1, ypad))
        new_image.paste(flipped_lr, (xpad - xsize + 1, ypad))

        new_image.paste(flipped_tb, (xpad, ypad + ysize - 1))
        new_image.paste(flipped_tb, (xpad, ypad - ysize + 1))

        new_image.paste(flipped_both, (xpad - xsize + 1, ypad - ysize + 1))
        new_image.paste(flipped_both, (xpad + xsize - 1, ypad - ysize + 1))
        new_image.paste(flipped_both, (xpad - xsize + 1, ypad + ysize - 1))
        new_image.paste(flipped_both, (xpad + xsize - 1, ypad + ysize - 1))

        new_image = new_image.crop((xpad - xtranslation,
                                    ypad - ytranslation,
                                    xpad + xsize - xtranslation,
                                    ypad + ysize - ytranslation))

        return new_image


class TransformTwice:
    def __init__(self, transform):
        self.transform = transform

    def __call__(self, inp):
        out1 = self.transform(inp)
        out2 = self.transform(inp)
        return out1, out2


def relabel_dataset(dataset, labels):
    unlabeled_idxs = []
    for idx in range(len(dataset.data)):
        path, _ = dataset.data[idx]
        filename = os.path.basename(path)
        if filename in labels:
            label_idx = dataset.class_to_idx[labels[filename]]
            dataset.data[idx] = path, label_idx
            del labels[filename]
        else:
            dataset.data[idx] = path, NO_LABEL
            unlabeled_idxs.append(idx)

    if len(labels) != 0:
        message = "List of unlabeled contains {} unknown files: {}, ..."
        some_missing = ', '.join(list(labels.keys())[:5])
        raise LookupError(message.format(len(labels), some_missing))

    labeled_idxs = sorted(set(range(len(dataset.data))) - set(unlabeled_idxs))

    return labeled_idxs, unlabeled_idxs


class TwoStreamBatchSampler(Sampler):
    """Iterate two sets of indices

    An 'epoch' is one iteration through the primary indices.
    During the epoch, the secondary indices are iterated through
    as many times as needed.
    """
    def __init__(self, primary_indices, secondary_indices, batch_size, secondary_batch_size, unlabeled_size_limit=None):
        self.primary_indices = primary_indices
        self.secondary_indices = secondary_indices
        self.secondary_batch_size = secondary_batch_size
        self.primary_batch_size = batch_size - secondary_batch_size
        self.unlabeled_size_limit = unlabeled_size_limit

        assert len(self.primary_indices) >= self.primary_batch_size > 0
        assert len(self.secondary_indices) >= self.secondary_batch_size > 0

    def __iter__(self):
        primary_iter = iterate_once(self.primary_indices, self.unlabeled_size_limit)
        secondary_iter = iterate_eternally(self.secondary_indices)
        return (
            primary_batch + secondary_batch
            for (primary_batch, secondary_batch)
            in  zip(grouper(primary_iter, self.primary_batch_size),
                    grouper(secondary_iter, self.secondary_batch_size))
        )

    def __len__(self):
        if self.unlabeled_size_limit is None:
            return len(self.primary_indices) // self.primary_batch_size
        else:
            return self.unlabeled_size_limit // self.primary_batch_size


def iterate_once(iterable, unlabeled_size_limit=None):
    if unlabeled_size_limit is None:
        return np.random.permutation(iterable)
    else:
        result = np.random.permutation(iterable)[:unlabeled_size_limit]
        return result


def iterate_eternally(indices):
    def infinite_shuffles():
        while True:
            yield np.random.permutation(indices)
    return itertools.chain.from_iterable(infinite_shuffles())


def grouper(iterable, n):
    "Collect data into fixed-length chunks or blocks"
    args = [iter(iterable)] * n
    return zip(*args)


def assert_exactly_one(lst):
    assert sum(int(bool(el)) for el in lst) == 1, ", ".join(str(el)
                                                            for el in lst)


def create_data_loaders(tran_transform,
                        test_transform,
                        config, args):
    print([config.data.exclude_unlabeled, config.training.labeled_batch_size])
    assert_exactly_one([config.data.exclude_unlabeled, config.training.labeled_batch_size])

    if config.data.dataset == 'CIFAR10':
        dataset = CIFAR10(os.path.join(args.run, 'datasets', 'cifar10'),
                          download=True, transform=tran_transform)
        test_dataset = CIFAR10(
            os.path.join(args.run, 'datasets', 'cifar10_test'),
            train=False, download=True, transform=test_transform)
    elif config.data.dataset == 'MNIST':
        dataset = MNIST(os.path.join(args.run, 'datasets', 'mnist'),
                        download=True, transform=tran_transform)
        test_dataset = MNIST(
            os.path.join(args.run, 'datasets', 'mnist_test'), train=False,
            download=True, transform=test_transform)

    elif config.data.dataset == 'CELEBA':
        if config.data.random_flip:
            dataset = CelebA(
                root=os.path.join(args.run, 'datasets', 'celeba'),
                transform=transforms.Compose([
                    transforms.CenterCrop(140),
                    transforms.Resize(config.data.image_size),
                    transforms.RandomHorizontalFlip(),
                    transforms.ToTensor(),
                ]), download=True)
        else:
            dataset = CelebA(
                root=os.path.join(args.run, 'datasets', 'celeba'),
                transform=transforms.Compose([
                    transforms.CenterCrop(140),
                    transforms.Resize(config.data.image_size),
                    transforms.ToTensor(),
                ]), download=True)

        test_dataset = CelebA(
            root=os.path.join(args.run, 'datasets', 'celeba_test'),
            split='test',
            transform=transforms.Compose([
                transforms.CenterCrop(140),
                transforms.Resize(config.data.image_size),
                transforms.ToTensor(),
            ]), download=True)

    elif config.data.dataset == 'SVHN':
        dataset = SVHN(os.path.join(args.run, 'datasets', 'svhn'),
                       download=True, transform=tran_transform)
        test_dataset = SVHN(
            os.path.join(args.run, 'datasets', 'svhn_test'), split='test',
            download=True,
            transform=test_transform)

    # Assign labels to a subset of inputs.
    unlabeled_idxs = []
    labeled_idxs = []
    if config.data.num_labels == len(dataset.targets):
        labeled_idxs = np.arange(len(dataset.targets))
    else:
        max_count = config.data.num_labels // config.num_targets  # each class lab data count
        print("Keeping %d labels per class." % max_count)
        mask_train = np.zeros(len(dataset.targets), dtype=np.float32)
        count = [0] * config.num_targets

        rstate = np.random.RandomState(seed=args.seed)
        indices = np.arange(len(dataset.targets))
        rstate.shuffle(indices)

        for i in indices:
            label = dataset.targets[i]
            if count[label] < max_count:
                mask_train[i] = 1.0
            count[label] += 1

        for i in range(len(dataset.targets)):
            unlabeled_idxs.append(i)
            if mask_train[i] != 1.0:
                dataset.targets[i] = NO_LABEL
                # unlabeled_idxs.append(i)
            else:
                labeled_idxs.append(i)

    # assert len(dataset.data) == len(labeled_idxs) + len(unlabeled_idxs)
    print('labeled & unlabeled idxs', len(labeled_idxs), len(unlabeled_idxs))

    if config.data.exclude_unlabeled or len(unlabeled_idxs) == 0:
        sampler = SubsetRandomSampler(labeled_idxs)
        batch_sampler = BatchSampler(sampler, config.training.batch_size,
                                     drop_last=True)
    elif config.training.labeled_batch_size:
        print("len(labeled_idxs)", len(labeled_idxs))
        batch_sampler = TwoStreamBatchSampler(
            unlabeled_idxs, labeled_idxs, config.training.batch_size,
            config.training.labeled_batch_size)
    else:
        assert False, "labeled batch size {}".format(config.training.labeled_batch_size)
    train_loader = DataLoader(
        dataset,
        batch_sampler=batch_sampler,
        num_workers=4,
        pin_memory=True
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=config.training.batch_size,
        shuffle=False,
        num_workers=4,
        drop_last=False
    )

    return train_loader, test_loader


def create_data_loaders_cifar100(train_transformation, eval_transformation, datadir, args, wtiny=False):
    # creating data loaders for CIFAR-100 with an option to add tiny images as unlabeled data
    traindir = os.path.join(datadir, args.train_subdir)
    evaldir = os.path.join(datadir, args.eval_subdir)
    print([args.exclude_unlabeled, args.labeled_batch_size])
    assert_exactly_one([args.exclude_unlabeled, args.labeled_batch_size])

    dataset = torchvision.datasets.ImageFolder(traindir, train_transformation)

    if args.labels:
        with open(args.labels) as f:
            labels = dict(line.split(' ') for line in f.read().splitlines())
        labeled_idxs, unlabeled_idxs = relabel_dataset(dataset, labels)
    assert len(dataset.data) == len(labeled_idxs) + len(unlabeled_idxs)
    orig_ds_size = len(dataset.data)

    if args.exclude_unlabeled or (len(unlabeled_idxs) == 0 and args.unsup_augment is None):
        sampler = SubsetRandomSampler(labeled_idxs)
        batch_sampler = BatchSampler(sampler, args.batch_size, drop_last=True)
    elif args.labeled_batch_size:
        if len(unlabeled_idxs) == 0: # in case of using all labels
            assert len(labeled_idxs) == 50000, 'Only supporting this case for now'
        print("len(labeled_idxs)", len(labeled_idxs))
        if args.unsup_augment is not None:
            print("Unsupervised Augmentation with CIFAR Tiny Images")
            from mean_teacher.tinyimages import TinyImages
            if args.unsup_augment == 'tiny_500k':
                extra_unlab_dataset = TinyImages(transform=train_transformation, which='500k')
            elif args.unsup_augment == 'tiny_237k':
                extra_unlab_dataset = TinyImages(transform=train_transformation, which='237k')
            elif args.unsup_augment == 'tiny_all':
                extra_unlab_dataset = TinyImages(transform=train_transformation, which='tiny_all')
            dataset = ConcatDataset([dataset, extra_unlab_dataset])
            unlabeled_idxs += [orig_ds_size + i for i in range(len(extra_unlab_dataset))]
            print("New unlabeled indices length", len(unlabeled_idxs))
        if args.unsup_augment is None:
            assert args.limit_unlabeled is None, 'With no unsup augmentation, limit_unlabeled should be None'
        batch_sampler = TwoStreamBatchSampler(
            unlabeled_idxs, labeled_idxs, args.batch_size, args.labeled_batch_size, unlabeled_size_limit=args.limit_unlabeled)
    else:
        assert False, "labeled batch size {}".format(args.labeled_batch_size)

    train_loader = DataLoader(dataset,
                              batch_sampler=batch_sampler,
                              num_workers=args.workers,
                              pin_memory=True)

    train_loader_len = len(train_loader)
    eval_loader = torch.utils.data.DataLoader(
        torchvision.datasets.ImageFolder(evaldir, eval_transformation),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=2 * args.workers,  # Needs images twice as fast
        pin_memory=True,
        drop_last=False)
    return train_loader, eval_loader, train_loader_len

def create_data_loaders_batch(tran_transform,
                        test_transform,
                        config, args):
    if config.data.dataset == 'CIFAR10':
        dataset = CIFAR10(os.path.join(args.run, 'datasets', 'cifar10'),
                          download=True, transform=tran_transform)
        test_dataset = CIFAR10(
            os.path.join(args.run, 'datasets', 'cifar10_test'),
            train=False, download=True, transform=test_transform)
    elif config.data.dataset == 'MNIST':
        dataset = MNIST(os.path.join(args.run, 'datasets', 'mnist'),
                        download=True, transform=tran_transform)
        test_dataset = MNIST(
            os.path.join(args.run, 'datasets', 'mnist_test'), train=False,
            download=True, transform=test_transform)
    elif config.data.dataset == 'CELEBA':
        transform = transforms.Compose([
                    transforms.CenterCrop(140),
                    transforms.Resize(config.data.image_size),
                    transforms.ToTensor()])
        data_dir = './run/datasets/celeba'
        data = np.load(os.path.join(data_dir, 'celebA_64x64.npy'))
        tensor_x = torch.Tensor(data) / 255.0
        tensor_y = torch.rand(202599)
        print(tensor_x.size())
        dataset = torch.utils.data.TensorDataset(tensor_x, tensor_y)
        #train_dataset = torchvision.datasets.ImageFolder('./run/datasets/celeba', transform)

        if False:
            test_dataset = CelebA(
                root=os.path.join(args.run, 'datasets', 'celeba_test'),
                split='test',
                transform=transforms.Compose([
                    transforms.CenterCrop(140),
                    transforms.Resize(config.data.image_size),
                    transforms.ToTensor(),
                ]), download=False)
        else:
            test_dataset = dataset

    train_loader = DataLoader(
        dataset,
        batch_size = config.training.batch_size,
        shuffle = False,
        #batch_sampler=batch_sampler,
        num_workers=4,
        pin_memory=True
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=config.training.batch_size,
        shuffle=False,
        num_workers=4,
        drop_last=False
    )

    return train_loader, test_loader




    # Assign labels to a subset of inputs.
    unlabeled_idxs = []
    labeled_idxs = []
    if config.data.num_labels == len(dataset.targets):
        labeled_idxs = np.arange(len(dataset.targets))
    else:
        max_count = config.data.num_labels // config.num_targets  # each class lab data count
        print("Keeping %d labels per class." % max_count)
        mask_train = np.zeros(len(dataset.targets), dtype=np.float32)
        count = [0] * config.num_targets

        rstate = np.random.RandomState(seed=args.seed)
        indices = np.arange(len(dataset.targets))
        rstate.shuffle(indices)

        for i in indices:
            label = dataset.targets[i]
            if count[label] < max_count:
                mask_train[i] = 1.0
            count[label] += 1

        for i in range(len(dataset.targets)):
            unlabeled_idxs.append(i)
            if mask_train[i] != 1.0:
                dataset.targets[i] = NO_LABEL
                # unlabeled_idxs.append(i)
            else:
                labeled_idxs.append(i)

    # assert len(dataset.data) == len(labeled_idxs) + len(unlabeled_idxs)
    print('labeled & unlabeled idxs', len(labeled_idxs), len(unlabeled_idxs))

    if config.data.exclude_unlabeled or len(unlabeled_idxs) == 0:
        sampler = SubsetRandomSampler(labeled_idxs)
        batch_sampler = BatchSampler(sampler, config.training.batch_size,
                                     drop_last=True)
    elif config.training.labeled_batch_size:
        print("len(labeled_idxs)", len(labeled_idxs))
        batch_sampler = TwoStreamBatchSampler(
            unlabeled_idxs, labeled_idxs, config.training.batch_size,
            config.training.labeled_batch_size)
    else:
        assert False, "labeled batch size {}".format(config.training.labeled_batch_size)
    train_loader = DataLoader(
        dataset,
        batch_sampler=batch_sampler,
        num_workers=4,
        pin_memory=True,
        drop_last=True
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=config.training.batch_size,
        shuffle=False,
        num_workers=4,
        drop_last=False
    )

    return train_loader, test_loader


