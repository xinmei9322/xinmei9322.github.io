import torch
import torch.nn as nn
import torch.nn.functional as F

def init_weight(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        m.weight.data.normal_(0., 0.02)
    elif classname.find('BatchNorm') != -1:
        m.weight.data.normal_(1., 0.02)
        m.bias.data.fill_(0.)

class Generator(nn.Module):
    def __init__(self, convs, in_channels):
        super(Generator, self).__init__()
        self.convs = nn.ModuleList()
        #in_channels = 1
        for i, (out_channels, kernel_size, stride, padding) in enumerate(convs):
            self.convs.append(nn.ConvTranspose2d(in_channels, out_channels, kernel_size, stride, padding, bias=False))
            if i < len(convs)-1:
                # we use BN and RELU for each layer except the output
                self.convs.append(nn.BatchNorm2d(out_channels))
                self.convs.append(nn.ReLU())
            else:
                # in output, we use Tanh to generate data in [-1, 1]
                self.convs.append(nn.Tanh())
            in_channels = out_channels
        self.apply(init_weight)

    def forward(self, input):
        out = input
        for module in self.convs:
            out = module(out)

        return out


def create_mnist_generator(config):
    ngf = config.model.ngf
    g_convs = [(ngf*4, 3, 2, 0), (ngf*2, 5, 2, 1),(ngf,4,2,1), (1, 4, 2, 1)]
    ###### nz + nz_x
    in_channels = config.model.nz + config.model.nz_x
    generator = Generator(g_convs, in_channels)
    return generator

def create_cifar10_generator(config):
    ngf = config.model.ngf
    #g_convs = [(ngf*4, 3, 2, 0), (ngf*2, 5, 2, 1),(ngf,4,2,1), (1, 4, 2, 1)]
    g_convs = [(ngf*4,4,1,0), (ngf*2,4,2,1), (ngf,4,2,1), (3,4,2,1)]
    ###### nz + nz_x
    in_channels = config.model.nz + config.model.nz_x
    generator = Generator(g_convs, in_channels)
    return generator

def create_celeba_generator(config):
    ngf = config.model.ngf
    #g_convs = [(ngf*4, 3, 2, 0), (ngf*2, 5, 2, 1),(ngf,4,2,1), (1, 4, 2, 1)]
    g_convs = [(ngf*4,4,1,0), (ngf*2,4,2,1), (ngf*2,4,2,1), (ngf,4,2,1), (3,4,2,1)]
    ###### nz + nz_x
    in_channels = config.model.nz + config.model.nz_x
    generator = Generator(g_convs, in_channels)
    return generator
