import torch
import torch.autograd as autograd
import torch.nn.functional as F


### K_XX, K_XY, K_YY
def _kernel_gram_matrix(X, Y, sigma_list= [1,4,8,11,16,20,32,64]):
    #assert(X.size(0) == Y.size(0))
    m_x = X.size(0)
    m_y = Y.size(0)

    Z = torch.cat((X, Y), 0)
    ZZT = torch.mm(Z, Z.t())
    diag_ZZT = torch.diag(ZZT).unsqueeze(1)
    Z_norm_sqr = diag_ZZT.expand_as(ZZT)
    exponent = Z_norm_sqr - 2 * ZZT + Z_norm_sqr.t()

    K = 0.0
    for sigma in sigma_list:
        gamma = 1.0 / (2 * sigma**2)
        K += torch.exp(-gamma * exponent)

    return K[:m_x, :m_x], K[:m_x, m_x:], K[m_x:, m_x:], len(sigma_list)

##### x is the conditional label
##### y is the target to generate
def cmmd(Xd,Yd,Xs,Ys, config, lambda_=0.01, biased=True):
    #Ks, Ksd, Kd, _ = _kernel_gram_matrix(Xs,Xd,sigma_list=[0.1])
    Ks, Ksd, Kd, _ = _kernel_gram_matrix(Xs,Xd,sigma_list=[10])

    #print(Ks[0])
    #print(Ksd[0])
    Ld, Lds, Ls, _ = _kernel_gram_matrix(Yd,Ys,sigma_list=[100])

    Kd_t = Kd + lambda_ * torch.eye(Kd.size(0)).to(config.device)
    Ks_t = Ks + lambda_ * torch.eye(Ks.size(0)).to(config.device)
    #Kd_t = Kd
    #Ks_t = Ks 

    Kd_t_inv = torch.inverse(Kd_t)
    Ks_t_inv = torch.inverse(Ks_t)
    #print(Kd_t_inv[0])
    #print(torch.transpose(Kd_t_inv,0,1)[0])

    #SS1 = torch.mm(Kd_t_inv,torch.mm(Kd,Kd_t_inv))
    #SS2 = torch.mm(Ks_t_inv,torch.mm(Ks,Ks_t_inv))
    #SS3 = torch.mm(Ks_t_inv,torch.mm(Ksd,Kd_t_inv))
    #print(SS1[0])
    #print(SS2[0])
    #print(SS3[0])


    #print(Kd_t_inv[:10])

    #tt = Kd_t_inv * Kd * Kd_t_inv
    #print('Kd_t_inv: ', Kd_t_inv[0])
    #print('Kd: ', Kd[0])
    #print('tt: ', tt[0])

    #print('Ksd size: ', Ksd.size())
    #print('Kd_t_inv size: ', Kd_t_inv.size())
    #print('Lds size: ', Lds.size())
    #print('Ks_t_inv size: ', Ks_t_inv.size())

    #print(torch.trace(torch.mm(torch.mm(torch.mm(Kd_t_inv, Kd),Kd_t_inv), Ld)))
    #print(torch.trace(torch.mm(torch.mm(torch.mm(Ks_t_inv,Ks), Ks_t_inv), Ls)))
    #print(torch.trace(torch.mm(torch.mm(torch.mm(Ks_t_inv,Ksd), Kd_t_inv), Lds)))

    #cmmd2 = torch.trace(torch.mm(torch.mm(torch.mm(Kd,Kd_t_inv), Ld), Kd_t_inv)) \
    #        + torch.trace(torch.mm(torch.mm(torch.mm(Ks, Ks_t_inv), Ls), Ks_t_inv)) \
    #        - 2 * torch.trace(torch.mm(torch.mm(torch.mm(Ksd, Kd_t_inv), Lds), Ks_t_inv))

    cmmd2 = torch.trace(torch.mm(torch.mm(torch.mm(Kd_t_inv, Kd),Kd_t_inv), Ld)) \
            + torch.trace(torch.mm(torch.mm(torch.mm(Ks_t_inv,Ks), Ks_t_inv), Ls)) \
            - 2 * torch.trace(torch.mm(torch.mm(torch.mm(Ks_t_inv,Ksd), Kd_t_inv), Lds))

    return cmmd2

def mmd(X,Y, config, const_diagonal=False, biased=False):
    K_XX, K_XY, K_YY, _ = _kernel_gram_matrix(X,Y)

    m_x = K_XX.size(0)  
    m_y = K_YY.size(0)  

    # Get the various sums of kernels that we'll use
    # Kts drop the diagonal, but we don't need to compute them explicitly
    if const_diagonal is not False:
        diag_X = diag_Y = const_diagonal
        sum_diag_X = m_x * const_diagonal
        sum_diag_Y = m_y * const_diagonal
    else:
        diag_X = torch.diag(K_XX)                       # (m,)
        diag_Y = torch.diag(K_YY)                       # (m,)
        sum_diag_X = torch.sum(diag_X)
        sum_diag_Y = torch.sum(diag_Y)

    Kt_XX_sums = K_XX.sum(dim=1) - diag_X             # \tilde{K}_XX * e = K_XX * e - diag_X
    Kt_YY_sums = K_YY.sum(dim=1) - diag_Y             # \tilde{K}_YY * e = K_YY * e - diag_Y
    K_XY_sums_0 = K_XY.sum(dim=0)                     # K_{XY}^T * e

    Kt_XX_sum = Kt_XX_sums.sum()                       # e^T * \tilde{K}_XX * e
    Kt_YY_sum = Kt_YY_sums.sum()                       # e^T * \tilde{K}_YY * e
    K_XY_sum = K_XY_sums_0.sum()                       # e^T * K_{XY} * e

    if biased:
        mmd2 = ((Kt_XX_sum + sum_diag_X) / (m_x * m_x)
            + (Kt_YY_sum + sum_diag_Y) / (m_y * m_y)
            - 2.0 * K_XY_sum / (m_x * m_y))
    else:
        mmd2 = (Kt_XX_sum / (m_x * (m_x - 1))
            + Kt_YY_sum / (m_y * (m_y - 1))
            - 2.0 * K_XY_sum / (m_x * m_y))

    return mmd2


