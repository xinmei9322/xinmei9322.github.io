# DBSN
Code for Deep Bayesian Structure Networks

env
```
python2/3, torch1.4.0, torchvision
```


train on classification tasks:
```
cd dbsn

run: mc dropout
python train.py --run dp0.2_0 --dataset cifar10 --ps --drop_rate 0.2

run: map fixed alpha
python train.py --run ds_0 --dataset cifar10 --method densenet

run: dbsn
python train.py --run adags_lr3_decayto0.5_0

run: map
python train.py --run ps_0 --dataset cifar10 --ps

run:darts
python train.py --run darts_0 --dataset cifar10 --ps --valid
```


retrain with found network structure:
```
CUDA_VISIBLE_DEVICES=0 python retrain_with_sampled_arch.py --run retrain_dbsn_seed0 --seed 0 --restore ../work/runadags_lr3_decayto0.5_0/alphas100.pth --dataset cifar10
CUDA_VISIBLE_DEVICES=0 python retrain_with_sampled_arch.py --ensemble ../work/runretrain_dbsn_seed{}

CUDA_VISIBLE_DEVICES=0 python retrain_with_sampled_arch.py --run retrain_dbsn_samearch_seed0 --seed 0 --load_arch ../work/runretrain_dbsn_seed0/archs10.pth --dataset cifar10
CUDA_VISIBLE_DEVICES=0 python retrain_with_sampled_arch.py --ensemble ../work/runretrain_dbsn_samearch_seed{}


```

train and test nek-fac (based on the [original implementation](https://github.com/pomonam/NoisyNaturalGradient)):
```
cd nng

CUDA_VISIBLE_DEVICES=0 python train.py --config config/classification/ekfac_vgg16_bn_aug.json
vgg11:
80 test cifari10: test | loss: 0.552116 | accuracy: 0.900800
80 test cifari100: test | loss: 2.951545 | accuracy: 0.610300

vgg16 (use this):
100 test cifari10: test | loss: 0.454479 | accuracy: 0.925700 | ece: 0.043436
100 test cifari100: test | loss: 2.784184 | accuracy: 0.625300 | ece: 0.166482

vgg13:
100 test cifari10: test | loss: 0.445817 | accuracy: 0.921800 | ece: 0.055207
100 test cifari100: test | loss: 2.729095 | accuracy: 0.623800 | ece: 0.250805
```

segmentation results:

`cd dbsn_seg`

`CUDA_VISIBLE_DEVICES=0 python train.py --model FCDenseNet67 --dir baseline_pw0.1`
> baseline_pw0.1 (3463243): Test - Loss: 0.3258 | Acc: 0.9040 | IOU: 0.6306 (0.92879747 0.80222609 0.29405931 0.94646308 0.82097352 0.75199645 0.40112767 0.32157756 0.7888852  0.48912112 0.39160665)


`CUDA_VISIBLE_DEVICES=0 python train.py --model DBSN --dir dbsn_bn_pw0.1_clip_3_1gpu`
> dbsn_bn_pw0.1_clip_3_1gpu (3319451): Test - Loss: 0.2822 | Acc: 0.9143 | IOU: 0.6538(800epoch)

> 100times: Test - Loss: 0.2759 | Acc: 0.9148 | IOU: 0.6556 (0.92821956 0.82942139 0.31693728 0.94421578 0.81509191 0.77227186 0.42254635 0.34969423 0.79376511 0.5721504  0.46677926)
