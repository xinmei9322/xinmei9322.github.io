#!/usr/bin/env python3

import argparse
import torch

import torch.nn as nn
import torch.optim as optim
import torch.backends.cudnn as cudnn

import torch.nn.functional as F
from torch.autograd import Variable

import torchvision.datasets as dset
import torchvision.transforms as transforms
from torchvision.utils import save_image

from torch.utils.data import DataLoader, Subset
from torch.distributions.relaxed_bernoulli import RelaxedBernoulli
from torch.distributions.bernoulli import Bernoulli

from architect import _ada_gumbel_softmax
from test import _ECELoss

import os
import sys
import math
import numpy as np
np.set_printoptions(precision=4)

import shutil
import glob
import logging

import stochastic_nn as stochastic_nn
from architect import GumbelSoftmaxMOptimizer, _ada_gumbel_softmax, PSOptimizer, DARTSOptimizer

def create_exp_dir(path, scripts_to_save=None):
  if not os.path.exists(path):
    os.mkdir(path)
  print('Experiment dir : {}'.format(path))

  if scripts_to_save is not None:
    if not os.path.exists(os.path.join(path, 'scripts')):
        os.mkdir(os.path.join(path, 'scripts'))
    for script in scripts_to_save:
      dst_file = os.path.join(path, 'scripts', os.path.basename(script))
      shutil.copyfile(script, dst_file)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--batchSz', type=int, default=64)
    parser.add_argument('--nEpochs', type=int, default=100)
    parser.add_argument('--no-cuda', action='store_true')
    parser.add_argument('--save')
    parser.add_argument('--run', type=str, default='dbsn')
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--dataset', type=str, default='cifar10')

    parser.add_argument('--opt', type=str, default='sgd', choices=('sgd', 'adam', 'rmsprop'))
    parser.add_argument('--net_learning_rate', type=float, default=0.1, help='learning rate for net')
    parser.add_argument('--net_weight_decay', type=float, default=1e-4, help='wd for arch encoding')
    parser.add_argument('--init_type', type=str, default='origin')
    parser.add_argument('--grad_clip', type=float, default=5., help='gradient clipping')
    parser.add_argument('--nesterov', action='store_true', default=False, help='use nesterov for net')
    parser.add_argument('--ncells', type=int, default=4)
    parser.add_argument('--nlayers', type=int, default=7)
    parser.add_argument('--drop_rate', type=float, default=0., help='drop_rate')
    parser.add_argument('--droppath_rate', type=float, default=0., help='droppath_rate')

    parser.add_argument('--after_norm_type', type=str, default='bn')
    parser.add_argument('--restore', type=str, default=None)
    parser.add_argument('--load_arch', type=str, default=None)
    parser.add_argument('--ensemble', type=str, default=None)
    args = parser.parse_args()

    if args.ensemble:
        logits = torch.cuda.FloatTensor(10, 10000, 10)
        for i in range(10):
            logits[i] = torch.from_numpy(np.load(args.ensemble.format(str(i)) + '/pred_logits.npy')).cuda()
        probs = torch.logsumexp(logits, 0) - np.log(10.)
        pred = probs.data.max(1)[1]
        labels = torch.from_numpy(np.array(dset.CIFAR10(root='../cifar', train=False, download=True).targets)).cuda()

        test_loss = F.nll_loss(probs, labels).item()
        incorrect = pred.ne(labels.data).cpu().sum()

        err = incorrect/100.
        ece = _ECELoss()(probs, labels, '../work/ensemble/')

        print('Test set: Average loss: {:.4f}, Error: {}/{} ({:.0f}%), Ece loss: {:.4f}'.format(
            test_loss, incorrect, 10000, err, ece.item()))
        return

    args.cuda = not args.no_cuda and torch.cuda.is_available()
    args.save = '../work/run{}'.format(args.run)
    create_exp_dir(args.save, scripts_to_save=glob.glob('*.py'))

    log_format = '%(asctime)s %(message)s'
    logging.basicConfig(stream=sys.stdout, level=logging.INFO,
        format=log_format, datefmt='%m/%d %I:%M:%S %p')
    fh = logging.FileHandler(os.path.join(args.save, 'log.txt'), mode="w+")
    fh.setFormatter(logging.Formatter(log_format))
    logging.getLogger().addHandler(fh)

    logging.info(str(args))

    np.random.seed(args.seed)
    torch.cuda.set_device(0)
    cudnn.benchmark = True
    torch.manual_seed(args.seed)
    cudnn.enabled=True
    torch.cuda.manual_seed(args.seed)
    ngpus = int(torch.cuda.device_count())
    logging.info("# of GPUs: " + str(ngpus))

    if args.dataset == "cifar10":
        normMean = [0.49139968, 0.48215827, 0.44653124]
        normStd = [0.24703233, 0.24348505, 0.26158768]
        normTransform = transforms.Normalize(normMean, normStd)
        nClasses = 10
        dataset_all = dset.CIFAR10
    elif args.dataset=="cifar100":
        normMean = [0.5071, 0.4867, 0.4408]
        normStd = [0.2675, 0.2565, 0.2761]
        normTransform = transforms.Normalize(normMean, normStd)
        nClasses = 100
        dataset_all = dset.CIFAR100

    trainTransform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normTransform
    ])
    testTransform = transforms.Compose([
        transforms.ToTensor(),
        normTransform
    ])

    trainLoader = DataLoader(
        dataset_all(root='../cifar', train=True, download=True,
                    transform=trainTransform),
                    batch_size=args.batchSz, shuffle=True,
                    pin_memory=True, num_workers=2, drop_last=True)
    testLoader = DataLoader(
        dataset_all(root='../cifar', train=False, download=True,
                     transform=testTransform),
                     batch_size=args.batchSz, shuffle=False,
                     pin_memory=True, num_workers=2)

    num_batch = len(trainLoader)
    logging.info(str(num_batch))

    if args.restore:
        alphas = torch.load(args.restore)
        betas = torch.load(args.restore.replace("alphas", "betas"))
        tau_min = 1.
        archs = _ada_gumbel_softmax(alphas, tau_min, betas).detach()
    elif args.load_arch:
        archs = torch.load(args.load_arch)
    else:
        raise Error

    archs.requires_grad_(False)
    print(archs.data.cpu().numpy())

    start_epoch = 1
    net = stochastic_nn.StochasticNet(growthRate=16, reduction=0.4, nClasses=nClasses, args=args).cuda()
    logging.info('  + Number of params: {}'.format(sum([p.data.nelement() for p in net.parameters()])))

    if args.opt == 'sgd':
        optimizer = optim.SGD(net.parameters(), lr=args.net_learning_rate, nesterov=args.nesterov,
                            momentum=0.9, weight_decay=args.net_weight_decay)
    elif args.opt == 'adam':
        optimizer = optim.Adam(net.parameters(), weight_decay=1e-4)
    elif args.opt == 'rmsprop':
        optimizer = optim.RMSprop(net.parameters(), weight_decay=1e-4)

    for epoch in range(start_epoch, args.nEpochs + 1):
        adjust_opt(args.opt, optimizer, epoch, args.nEpochs)
        train(args, epoch, net, trainLoader, optimizer, archs)
        if epoch % 10 == 0:
            test(args, epoch, num_batch, net, testLoader, archs, ngpus)
            torch.save(net, os.path.join(args.save, 'epoch{}.pth'.format(epoch)))
            torch.save(archs, os.path.join(args.save, 'archs{}.pth'.format(epoch)))

def train(args, epoch, net, trainLoader, optimizer, archs):
    net.train()
    counter = (epoch - 1) * len(trainLoader)
    nProcessed = 0
    nTrain = len(trainLoader.dataset)
    train_loss = 0
    incorrect = 0
    for batch_idx, (data, target) in enumerate(trainLoader):
        if args.cuda:
            data, target = data.cuda(non_blocking=True), target.cuda(non_blocking=True)
        optimizer.zero_grad()
        output = net(data, archs)
        loss = F.nll_loss(output, target)
        loss.backward()
        # nn.utils.clip_grad_norm_(net.parameters(), args.grad_clip)
        optimizer.step()

        nProcessed += len(data)
        train_loss += loss
        pred = output.data.max(1)[1] # get the index of the max log-probability
        incorrect += pred.ne(target.data).cpu().sum()
        counter += 1
    train_loss /= len(trainLoader) # loss function already averages over batch size
    err = 100.*incorrect/nProcessed
    logging.info('Epoch: {} training weights: Average loss: {:.4f}, Error: {}/{} ({:.0f}%)'.format(epoch,
        train_loss, incorrect, nProcessed, err))

def test(args, epoch, num_batch, net, testLoader, archs, ngpus):

    net.eval()
    test_loss = 0
    incorrect = 0
    logits = []
    labels = []
    for data, target in testLoader:
        data, target = data.cuda(non_blocking=True), target.cuda(non_blocking=True)
        with torch.no_grad():
            output = net(data, archs)
        logits.append(output)
        labels.append(target)
        test_loss += F.nll_loss(output, target).item()
        pred = output.data.max(1)[1] # get the index of the max log-probability
        incorrect += pred.ne(target.data).cpu().sum()

    test_loss = test_loss
    test_loss /= len(testLoader) # loss function already averages over batch size
    nTotal = len(testLoader.dataset)
    err = 100.*incorrect/nTotal
    ece = _ECELoss()(torch.cat(logits, 0), torch.cat(labels, 0), args.save)
    if epoch == args.nEpochs:
        np.save(args.save + "/pred_logits.npy", torch.cat(logits, 0).data.cpu().numpy())
    logging.info('Test set: Average loss: {:.4f}, Error: {}/{} ({:.0f}%), Ece loss: {:.4f}'.format(
        test_loss, incorrect, nTotal, err, ece.item()))

def adjust_opt(optAlg, optimizer, epoch, nEpochs):
    if optAlg == 'sgd':
        if epoch == 1:
            lr = 1e-1
        elif epoch == 61:
            lr = 1e-2
        elif epoch == 81:
            lr = 1e-3
        else: return

        for param_group in optimizer.param_groups:
            param_group['lr'] = lr

if __name__=='__main__':
    main()
