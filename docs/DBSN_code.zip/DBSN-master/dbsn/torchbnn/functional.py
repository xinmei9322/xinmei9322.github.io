import math
import torch

from .modules import *

def _kl_loss(mu_0, log_sigma_0, mu_1, log_sigma_1) :
    """
    An method for calculating KL divergence between two Normal distribtuion.
    Arguments:
        mu_0 (Float) : mean of normal distribution.
        log_sigma_0 (Float): log(standard deviation of normal distribution).
        mu_1 (Float): mean of normal distribution.
        log_sigma_1 (Float): log(standard deviation of normal distribution).

    """
    kl = log_sigma_1 - log_sigma_0 + \
    (torch.exp(log_sigma_0)**2 + (mu_0-mu_1)**2)/(2*math.exp(log_sigma_1)**2) - 0.5
    return kl.sum()

def gaussian_log_p(mu, log_sigma, input):
    return (-math.log(math.sqrt(2 * math.pi))
            - log_sigma
            - ((input - mu) ** 2) / (2 * torch.exp(log_sigma) ** 2))

def _kl_loss_scale_mixture(mu_0, log_sigma_0, input, pi=0.5, log_sigma_1=torch.cuda.FloatTensor([-0]), log_sigma_2=torch.cuda.FloatTensor([-6])) :
    kl = gaussian_log_p(mu_0, log_sigma_0, input) - torch.log(pi * gaussian_log_p(0, log_sigma_1, input).exp() + (1-pi) * gaussian_log_p(0, log_sigma_2, input).exp())
    return kl.sum()

def bayesian_kl_loss(bnn_layers, reduction='sum', last_layer_only=False) :

    # device = torch.device("cuda" if next(model.parameters()).is_cuda else "cpu")
    # kl = torch.Tensor([0]).to(device)
    kl_sum = torch.Tensor([0]).cuda()
    n = torch.Tensor([0]).cuda()

    for m in bnn_layers:
        if isinstance(m, (BayesLinear, BayesConv2d)):
            kl = _kl_loss(m.weight_mu, m.weight_log_sigma, m.prior_mu, m.prior_log_sigma) #_kl_loss_scale_mixture(m.weight_mu, m.weight_log_sigma, m.weight) #
            kl_sum += kl
            n += len(m.weight_mu.view(-1))

            if m.bias :
                kl = _kl_loss(m.bias_mu, m.bias_log_sigma, m.prior_mu, m.prior_log_sigma) #_kl_loss_scale_mixture(m.bias_mu, m.bias_log_sigma, m.bias_t) #
                kl_sum += kl
                n += len(m.bias_mu.view(-1))

        # elif isinstance(m, BayesBatchNorm2d):
        #     if m.affine :
        #         kl = _kl_loss(m.weight_mu, m.weight_log_sigma, m.prior_mu, m.prior_log_sigma)
        #         kl_sum += kl
        #         n += len(m.weight_mu.view(-1))
        #
        #         kl = _kl_loss(m.bias_mu, m.bias_log_sigma, m.prior_mu, m.prior_log_sigma)
        #         kl_sum += kl
        #         n += len(m.bias_mu.view(-1))
        else:
            raise Error()

    if last_layer_only or n == 0 :
        return kl

    if reduction == 'mean' :
        return kl_sum/n
    elif reduction == 'sum' :
        return kl_sum
    else :
        raise ValueError(reduction + " is not valid")
